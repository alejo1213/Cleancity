

import { useState } from "react";
import Header from "./components/Header";
import Usuario from "./components/Usuario";
import Ubicacion from "./components/Ubicacion";
import AtencionUsuario from "./components/AtencionUsuario";
import "./App.css";

function App() {
  const [vista, setVista] = useState("inicio");

  const usuario = {
    idUsuario: 1,
    nombre: "Alejandro",
    cedula: "123456789",
    correo: "alejandro@gmail.com",
    telefono: "3001234567",
  };

  const ubicacion = {
    idUbicacion: 1,
    direccion: "Santa Rosa de Osos, Antioquia",
    latitud: 6.647,
    longitud: -75.460,
  };

  return (
    <div>
      <Header
        mostrarUsuario={() => setVista("usuario")}
        mostrarUbicacion={() => setVista("ubicacion")}
        mostrarAtencionUsuario={() => setVista("atencion")}
      />

      {vista === "usuario" && (
        <Usuario
          usuario={usuario}
          ubicacion={ubicacion}
        />
      )}

      {vista === "ubicacion" && (
        <Ubicacion
          ubicacion={ubicacion}
          usuario={usuario}
        />
      )}

      {vista === "inicio" && (
        <h2>Bienvenido a CleanCity 🌱</h2>
      )}

      {vista === "atencion" && <AtencionUsuario />}
    </div>
  );
}

export default App;

