
import { useState } from "react";

function AtencionUsuario() {
  const [nombre, setNombre] = useState("");
  const [correo, setCorreo] = useState("");
  const [tipoSolicitud, setTipoSolicitud] = useState("Consulta");
  const [mensaje, setMensaje] = useState("");

  function enviarSolicitud(event) {
    event.preventDefault();

    alert(
      "Solicitud registrada en la interfaz. ¡Gracias por contactarnos, " +
      nombre +
      "!"
    );

    setNombre("");
    setCorreo("");
    setTipoSolicitud("Consulta");
    setMensaje("");
  }

  return (
    <div className="atencion-container">
      <div className="atencion-card">
        <h2>💬 Atención al usuario</h2>

        <p>
          ¿Necesitas ayuda con CleanCity?
          Envíanos tu solicitud.
        </p>

        <form onSubmit={enviarSolicitud}>
          <label>Nombre completo</label>
          <input
            type="text"
            value={nombre}
            onChange={(event) => setNombre(event.target.value)}
            placeholder="Escribe tu nombre"
            required
          />

          <label>Correo electrónico</label>
          <input
            type="email"
            value={correo}
            onChange={(event) => setCorreo(event.target.value)}
            placeholder="ejemplo@correo.com"
            required
          />

          <label>Tipo de solicitud</label>
          <select
            value={tipoSolicitud}
            onChange={(event) => setTipoSolicitud(event.target.value)}
          >
            <option value="Consulta">Consulta</option>
            <option value="Queja">Queja</option>
            <option value="Reclamo">Reclamo</option>
            <option value="Sugerencia">Sugerencia</option>
            <option value="Ayuda con un reporte">
              Ayuda con un reporte
            </option>
          </select>

          <label>Describe tu solicitud</label>
          <textarea
            value={mensaje}
            onChange={(event) => setMensaje(event.target.value)}
            placeholder="Cuéntanos cómo podemos ayudarte..."
            rows="5"
            required
          />

          <button type="submit">
            Enviar solicitud
          </button>
        </form>
      </div>
    </div>
  );
}

export default AtencionUsuario;
